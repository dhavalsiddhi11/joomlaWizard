# Changelog

## 1.0.2

### Fixed

- Check installer script class

## 1.0.1

### Fixed

- Updated language strings

## 1.0.0

### New

- Initial release
