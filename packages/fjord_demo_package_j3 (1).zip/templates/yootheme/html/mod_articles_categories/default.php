<?php

defined('_JEXEC') or die;

?>
<ul>
    <?php require JModuleHelper::getLayoutPath('mod_articles_categories', $params->get('layout', 'default') . '_items'); ?>
</ul>
