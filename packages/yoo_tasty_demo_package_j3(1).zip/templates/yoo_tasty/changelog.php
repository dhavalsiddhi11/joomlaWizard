<?php
/**
* @package   yoo_tasty
* @author    YOOtheme http://www.yootheme.com
* @copyright Copyright (C) YOOtheme GmbH
* @license   http://www.gnu.org/licenses/gpl.html GNU/GPL
*/

// no direct access
die('Restricted access');

?>

Changelog
------------

1.0.3
# Fixed menu-dropdown starting with level2

1.0.2
# Updated space between menu parent images

1.0.1
# Fixed social icons order

1.0.0
+ Initial Release


* -> Security Fix
# -> Bug Fix
$ -> Language fix or change
+ -> Addition
^ -> Change
- -> Removed
! -> Note