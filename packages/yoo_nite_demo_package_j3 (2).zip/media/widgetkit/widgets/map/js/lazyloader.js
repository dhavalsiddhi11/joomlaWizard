/* Copyright (C) YOOtheme GmbH, YOOtheme Proprietary Use License (http://www.yootheme.com/license) */

(function($){$widgetkit.lazyloaders["googlemaps"]=function(element,options){$widgetkit.load(WIDGETKIT_URL+"/widgets/map/js/map.js").done(function(){element.googlemaps(options)})}})(jQuery);