# Changelog

    1.0.10
    ^ Updated do not force vertical scrollbar

    1.0.9
    # Fixed document height for uk-modal component

	1.0.8
	^ Updated UIkit theme according to UIkit 2.20.0
	# Fixed Article Navigation (J)

    1.0.7
    ^ Updated UIkit theme according to UIkit 2.17.0

    1.0.6
    ^ Updated UIkit theme according to UIkit 2.16.0

    1.0.5
    ^ Updated UIkit theme according to UIkit 2.15.0

    1.0.4
    ^ Updated UIkit theme according to UIkit 2.1.1

    1.0.3
    + Added WooCommerce Layer
    ^ Updated UIkit theme according to UIkit 2.1.0
    # Added a setTimeOut delay in the theme.js to fix the navbar / logo calculation issue

    1.0.2
    ^ Updated UIkit theme according to UIkit 2.8.0
    # Fixed top calculation of tm-fullscreen container in theme.less

    1.0.1
    # Fixed calculations of fullscreen container when navbar is not fixed in the theme.less

    1.0.0
    + Initial Release



    * -> Security Fix
    # -> Bug Fix
    $ -> Language fix or change
    + -> Addition
    ^ -> Change
    - -> Removed
    ! -> Note
