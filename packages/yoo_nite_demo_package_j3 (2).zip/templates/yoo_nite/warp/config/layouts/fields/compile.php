<p><a href="#compile" class="uk-button">Compile LESS</a></p>

<p><span class="uk-badge">Note</span> Compiling LESS will replace all related CSS files. All styles will be compiled at once.</p>

<div id="compilemodal" class="uk-modal">
	<div class="uk-modal-dialog">
		<h1 class="uk-h3">Compiling Less...</h1>
		<p class="file-name uk-text-muted"></p>
		<div class="uk-progress">
			<div class="uk-progress-bar" style="width: 0%;"></div>
		</div>
		<div class="error-list">

		</div>
		<div>
			<button type="button" class="uk-button uk-button-danger">Cancel</button>
		</div>
	</div>
</div>
